import React, { Component } from "react";
import { StyleSheet, View } from "react-native";
import Icon from "react-native-vector-icons/MaterialIcons";
import LogoHeader from "./LogoHeader";

function HeaderX(props) {
  return (
    <View style={[styles.container, props.style]}>
      <View style={styles.group}>
        <View style={styles.iconRow}>
          <Icon name="dehaze" style={styles.icon}></Icon>
          <LogoHeader
            text1=""
            rect1="rgba(31,178,204,1)"
            style={styles.logoHeader}
          ></LogoHeader>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "rgba(33,211,184,1)"
  },
  group: {
    width: 360,
    height: 55,
    backgroundColor: "rgba(33,210,184,1)",
    flexDirection: "row",
    marginTop: 25
  },
  icon: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    width: 18,
    height: 25,
    marginTop: 10
  },
  logoHeader: {
    width: 104,
    height: 44,
    marginLeft: 78
  },
  iconRow: {
    height: 44,
    flexDirection: "row",
    flex: 1,
    marginRight: 128,
    marginLeft: 32,
    marginTop: -7
  }
});

export default HeaderX;
