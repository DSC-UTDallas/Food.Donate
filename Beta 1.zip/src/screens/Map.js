import React, { Component } from "react";
import { StyleSheet, View, StatusBar } from "react-native";
import HeaderX from "../components/HeaderX";
import MapView from "react-native-maps";

function Map(props) {
  return (
    <View style={styles.root}>
      <HeaderX
        icon2Family="Feather"
        icon2Name="search"
        style={styles.headerX}
      ></HeaderX>
      <View style={styles.body}>
        <View style={styles.rect}>
          <View style={styles.mapViewFiller}></View>
          <MapView
            provider={MapView.PROVIDER_GOOGLE}
            initialRegion={{
              latitude: 37.78825,
              longitude: -122.4324,
              latitudeDelta: 0.0922,
              longitudeDelta: 0.0421
            }}
            customMapStyle={[]}
            style={styles.mapView}
          ></MapView>
        </View>
      </View>
      <StatusBar
        barStyle="light-content"
        hidden={false}
        backgroundColor="rgba(0,0,0,0)"
      ></StatusBar>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: "rgb(255,255,255)"
  },
  headerX: {
    width: 360,
    height: 80,
    elevation: 15,
    shadowOffset: {
      height: 7,
      width: 1
    },
    shadowColor: "rgba(0,0,0,1)",
    shadowOpacity: 0.1,
    shadowRadius: 5,
    alignSelf: "center"
  },
  body: {
    width: 360,
    flex: 1,
    alignSelf: "center"
  },
  rect: {
    width: 360,
    height: 608,
    backgroundColor: "rgba(230, 230, 230,1)",
    flexDirection: "row",
    marginTop: 52
  },
  mapViewFiller: {
    flex: 1,
    flexDirection: "row"
  },
  mapView: {
    height: 608,
    width: 360
  }
});

export default Map;
