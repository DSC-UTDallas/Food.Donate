import React, { Component } from "react";
import {
  StyleSheet,
  View,
  ImageBackground,
  Text,
  TextInput,
  StatusBar
} from "react-native";
import HeaderX from "../components/HeaderX";
import EntypoIcon from "react-native-vector-icons/Entypo";
import FontAwesomeIcon from "react-native-vector-icons/FontAwesome";
import IoniconsIcon from "react-native-vector-icons/Ionicons";

function Input(props) {
  return (
    <View style={styles.root}>
      <HeaderX style={styles.headerX}></HeaderX>
      <View style={styles.body}>
        <View style={styles.backgroundStack}>
          <View style={styles.background}>
            <ImageBackground
              style={styles.rect7}
              imageStyle={styles.rect7_imageStyle}
              source={require("../assets/images/Gradient_LZGIVfZ.png")}
            ></ImageBackground>
          </View>
          <View style={styles.feedbackBox}>
            <View style={styles.text4Column}>
              <Text style={styles.text4}>INVENTORY</Text>
              <Text style={styles.text42}>Enter inventory items here:</Text>
              <View style={styles.form}>
                <View style={styles.name}>
                  <EntypoIcon
                    name={props.iconName || "leaf"}
                    style={styles.icon3}
                  ></EntypoIcon>
                  <TextInput
                    placeholder="Item Title"
                    placeholderTextColor="rgba(253,248,248,1)"
                    style={styles.textInput2}
                  ></TextInput>
                </View>
                <View style={styles.nameFiller}></View>
                <View style={styles.emailColumn}>
                  <View style={styles.email}>
                    <FontAwesomeIcon
                      name={props.iconName || "signal"}
                      style={styles.icon4}
                    ></FontAwesomeIcon>
                    <TextInput
                      placeholder="Quantity"
                      placeholderTextColor="rgba(251,246,246,1)"
                      style={styles.textInput3}
                    ></TextInput>
                  </View>
                  <View style={styles.rect9}>
                    <FontAwesomeIcon
                      name={props.iconName || "battery-2"}
                      style={styles.icon6}
                    ></FontAwesomeIcon>
                    <TextInput
                      placeholder="Expiration Date"
                      placeholderTextColor="rgba(251,246,246,1)"
                      style={styles.textInput5}
                    ></TextInput>
                  </View>
                </View>
              </View>
            </View>
            <View style={styles.text4ColumnFiller}></View>
            <View style={styles.rect8}>
              <View style={styles.textInput4Stack}>
                <TextInput
                  placeholder="Additional Comments"
                  placeholderTextColor="rgba(255,255,255,1)"
                  style={styles.textInput4}
                ></TextInput>
                <IoniconsIcon
                  name="md-arrow-forward"
                  style={styles.icon5}
                ></IoniconsIcon>
              </View>
            </View>
          </View>
        </View>
      </View>
      <StatusBar
        barStyle="light-content"
        hidden={false}
        backgroundColor="rgba(0,0,0,0)"
      ></StatusBar>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: "rgb(255,255,255)"
  },
  headerX: {
    width: 360,
    height: 80,
    elevation: 15,
    shadowOffset: {
      height: 7,
      width: 1
    },
    shadowColor: "rgba(0,0,0,1)",
    shadowOpacity: 0.1,
    shadowRadius: 5,
    alignSelf: "center"
  },
  body: {
    width: 360,
    flex: 1,
    marginBottom: -125,
    marginTop: 308
  },
  background: {
    top: 305,
    width: 360,
    height: 330,
    position: "absolute",
    left: 0
  },
  rect7: {
    width: 360,
    height: 666,
    marginTop: -310
  },
  rect7_imageStyle: {
    opacity: 0.69
  },
  feedbackBox: {
    top: 0,
    width: 360,
    height: 330,
    position: "absolute",
    left: 0
  },
  text4: {
    color: "rgba(255,255,255,1)",
    fontSize: 24,
    marginLeft: 70
  },
  text42: {
    color: "rgba(255,255,255,1)",
    fontSize: 12,
    marginTop: 13,
    marginLeft: 68
  },
  form: {
    width: 280,
    height: 116,
    marginTop: 29
  },
  name: {
    height: 50,
    backgroundColor: "rgba(255,255,255,0.3)",
    opacity: 1,
    borderRadius: 5,
    width: 280,
    flexDirection: "row",
    alignSelf: "flex-end"
  },
  icon3: {
    color: "rgba(255,255,255,1)",
    fontSize: 20,
    marginLeft: 21,
    alignSelf: "center"
  },
  textInput2: {
    height: 30,
    color: "rgba(255,255,255,1)",
    fontSize: 14,
    flex: 1,
    marginRight: 20,
    marginLeft: 19,
    alignSelf: "center"
  },
  nameFiller: {
    flex: 1
  },
  email: {
    height: 50,
    backgroundColor: "rgba(251,247,247,0.3)",
    opacity: 1,
    borderRadius: 5,
    width: 280,
    flexDirection: "row",
    alignSelf: "flex-end",
    marginBottom: 15
  },
  icon4: {
    color: "rgba(255,255,255,1)",
    fontSize: 18,
    marginLeft: 23,
    alignSelf: "center"
  },
  textInput3: {
    height: 30,
    color: "rgba(255,255,255,1)",
    fontSize: 14,
    flex: 1,
    marginRight: 20,
    marginLeft: 19,
    alignSelf: "center"
  },
  rect9: {
    height: 50,
    backgroundColor: "rgba(251,247,247,0.3)",
    opacity: 1,
    borderRadius: 5,
    flexDirection: "row"
  },
  icon6: {
    color: "rgba(255,255,255,1)",
    fontSize: 18,
    marginLeft: 23,
    alignSelf: "center"
  },
  textInput5: {
    height: 30,
    color: "rgba(255,255,255,1)",
    fontSize: 14,
    flex: 1,
    marginRight: 20,
    marginLeft: 14,
    alignSelf: "center"
  },
  emailColumn: {
    marginBottom: -65
  },
  text4Column: {
    width: 280,
    marginTop: 38,
    marginLeft: 40
  },
  text4ColumnFiller: {
    flex: 1
  },
  rect8: {
    width: 292,
    borderColor: "rgba(255,255,255,1)",
    borderWidth: 0,
    borderBottomWidth: 1,
    height: 49,
    marginBottom: -32,
    alignSelf: "center"
  },
  textInput4: {
    top: 0,
    left: 0,
    color: "rgba(255,255,255,1)",
    position: "absolute",
    right: 0,
    bottom: 0,
    fontSize: 12
  },
  icon5: {
    position: "absolute",
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    right: 0,
    top: 12
  },
  textInput4Stack: {
    flex: 1,
    marginBottom: 3
  },
  backgroundStack: {
    width: 360,
    height: 635,
    marginTop: -305
  }
});

export default Input;
