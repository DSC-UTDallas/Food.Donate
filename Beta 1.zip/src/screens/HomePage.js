import React, { Component } from "react";
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  ImageBackground,
  StatusBar
} from "react-native";
import HeaderX from "../components/HeaderX";

function HomePage(props) {
  return (
    <View style={styles.root}>
      <View style={styles.pageName1StackColumn}>
        <View style={styles.pageName1Stack}>
          <Text style={styles.pageName1}></Text>
          <Text style={styles.pageName2}>inventory input</Text>
          <TouchableOpacity
            onPress={() => props.navigation.navigate("Input")}
            style={styles.button3}
          >
            <Text style={styles.text4}>Inventory Input</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.tabs1}>
          <TouchableOpacity style={styles.button2}>
            <Text style={styles.text3}>Home Page</Text>
          </TouchableOpacity>
        </View>
        <HeaderX icon2Name="power" style={styles.headerX}></HeaderX>
      </View>
      <View style={styles.body1}>
        <View style={styles.background}>
          <ImageBackground
            style={styles.rect7}
            imageStyle={styles.rect7_imageStyle}
            source={require("../assets/images/Gradient_LZGIVfZ.png")}
          ></ImageBackground>
        </View>
      </View>
      <View style={styles.button32Column}>
        <TouchableOpacity
          onPress={() => props.navigation.navigate("Inventory")}
          style={styles.button32}
        >
          <Text style={styles.text5}>Inventory</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => props.navigation.navigate("Map")}
          style={styles.button4}
        >
          <Text style={styles.text6}>Map</Text>
        </TouchableOpacity>
      </View>
      <StatusBar
        barStyle="light-content"
        hidden={false}
        backgroundColor="rgba(0,0,0,0)"
      ></StatusBar>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: "rgb(255,255,255)"
  },
  pageName1: {
    top: 49,
    left: 109,
    color: "rgba(255,255,255,1)",
    position: "absolute",
    fontSize: 24
  },
  pageName2: {
    top: 49,
    left: 93,
    color: "rgba(255,255,255,1)",
    position: "absolute",
    fontSize: 24
  },
  button3: {
    left: 0,
    width: 360,
    height: 61,
    backgroundColor: "rgba(251,247,247,0.3)",
    position: "absolute",
    bottom: 12,
    borderRadius: 5
  },
  text4: {
    color: "rgba(255,255,255,1)",
    marginTop: 24,
    marginLeft: 134
  },
  pageName1Stack: {
    width: 360,
    height: 73,
    marginTop: 149
  },
  tabs1: {
    width: 360,
    height: 52,
    backgroundColor: "rgba(31,178,204,1)",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-around",
    elevation: 0,
    shadowOffset: {
      height: 0,
      width: 0
    },
    shadowColor: "rgba(0,0,0,1)",
    shadowRadius: 0,
    marginTop: -142
  },
  button2: {
    width: 100,
    height: 38,
    backgroundColor: "rgba(247,247,247,0)",
    alignSelf: "center",
    opacity: 1,
    borderRadius: 100
  },
  text3: {
    color: "rgba(255,255,255,1)",
    marginTop: 10,
    marginLeft: 14
  },
  headerX: {
    width: 360,
    height: 80,
    elevation: 15,
    shadowOffset: {
      height: 7,
      width: 1
    },
    shadowColor: "rgba(0,0,0,1)",
    shadowOpacity: 0.1,
    shadowRadius: 5,
    marginTop: -132
  },
  pageName1StackColumn: {
    width: 360
  },
  body1: {
    width: 360,
    flex: 1,
    marginBottom: -637,
    marginTop: 166,
    alignSelf: "center"
  },
  background: {
    width: 360,
    height: 330,
    alignSelf: "center"
  },
  rect7: {
    width: 360,
    height: 666,
    marginTop: -314,
    alignSelf: "center"
  },
  rect7_imageStyle: {
    opacity: 0.69
  },
  button32: {
    width: 360,
    height: 61,
    backgroundColor: "rgba(251,247,247,0.3)",
    borderRadius: 5,
    marginBottom: 20
  },
  text5: {
    color: "rgba(255,255,255,1)",
    marginTop: 23,
    marginLeft: 152
  },
  button4: {
    width: 360,
    height: 61,
    backgroundColor: "rgba(251,247,247,0.3)",
    borderRadius: 5
  },
  text6: {
    color: "rgba(255,255,255,1)",
    marginTop: 26,
    marginLeft: 167
  },
  button32Column: {
    width: 360,
    marginBottom: 370
  }
});

export default HomePage;
