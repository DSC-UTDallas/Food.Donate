import React, { Component } from "react";
import { StyleSheet, View, TouchableOpacity } from "react-native";
import Icon from "react-native-vector-icons/MaterialIcons";
import LogoHeader from "./LogoHeader";

function HeaderX(props) {
  return (
    <View style={[styles.container, props.style]}>
      <View style={styles.group}>
        <View style={styles.iconStackRow}>
          <View style={styles.iconStack}>
            <Icon name="dehaze" style={styles.icon}></Icon>
            <TouchableOpacity
              onPress={() => console.log("Navigate to HomePage")}
              style={styles.button}
            ></TouchableOpacity>
          </View>
          <LogoHeader
            text1=""
            rect1="rgba(31,178,204,1)"
            style={styles.logoHeader}
          ></LogoHeader>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "rgba(33,211,184,1)"
  },
  group: {
    width: 360,
    height: 55,
    backgroundColor: "rgba(33,210,184,1)",
    flexDirection: "row",
    marginTop: 25,
    alignSelf: "center"
  },
  icon: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    width: 18,
    position: "absolute",
    left: 0,
    height: 25,
    top: 3
  },
  button: {
    top: 0,
    left: 0,
    width: 19,
    height: 28,
    position: "absolute"
  },
  iconStack: {
    width: 19,
    height: 28,
    marginTop: 7
  },
  logoHeader: {
    width: 104,
    height: 44,
    marginLeft: 77
  },
  iconStackRow: {
    height: 44,
    flexDirection: "row",
    flex: 1,
    marginRight: 128,
    marginLeft: 32,
    marginTop: -7
  }
});

export default HeaderX;
