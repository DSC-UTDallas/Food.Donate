import React, { Component } from "react";
import {
  StyleSheet,
  View,
  StatusBar,
  TouchableOpacity,
  Text
} from "react-native";
import HeaderX from "../components/HeaderX";
import MaterialCardWithImageAndTitle from "../components/MaterialCardWithImageAndTitle";

function Inventory(props) {
  return (
    <View style={styles.root}>
      <StatusBar
        barStyle="light-content"
        hidden={false}
        backgroundColor="rgba(0,0,0,0)"
      ></StatusBar>
      <HeaderX style={styles.headerX}></HeaderX>
      <View style={styles.tabs1}>
        <TouchableOpacity style={styles.button}>
          <Text style={styles.text3}>Inventory</Text>
        </TouchableOpacity>
      </View>
      <MaterialCardWithImageAndTitle
        style={styles.carrots}
      ></MaterialCardWithImageAndTitle>
      <MaterialCardWithImageAndTitle
        style={styles.eggs}
      ></MaterialCardWithImageAndTitle>
      <View style={styles.materialCardWithImageAndTitle2Stack}>
        <MaterialCardWithImageAndTitle
          style={styles.materialCardWithImageAndTitle2}
        ></MaterialCardWithImageAndTitle>
        <MaterialCardWithImageAndTitle
          style={styles.materialCardWithImageAndTitle3}
        ></MaterialCardWithImageAndTitle>
      </View>
      <MaterialCardWithImageAndTitle
        style={styles.materialCardWithImageAndTitle4}
      ></MaterialCardWithImageAndTitle>
      <MaterialCardWithImageAndTitle
        style={styles.materialCardWithImageAndTitle5}
      ></MaterialCardWithImageAndTitle>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: "rgb(255,255,255)"
  },
  headerX: {
    height: 80,
    elevation: 15,
    shadowOffset: {
      height: 7,
      width: 1
    },
    shadowColor: "rgba(0,0,0,1)",
    shadowOpacity: 0.1,
    shadowRadius: 5
  },
  tabs1: {
    width: 360,
    height: 52,
    backgroundColor: "rgba(31,178,204,1)",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-around",
    elevation: 0,
    shadowOffset: {
      height: 0,
      width: 0
    },
    shadowColor: "rgba(0,0,0,1)",
    shadowRadius: 0
  },
  button: {
    width: 100,
    height: 38,
    backgroundColor: "rgba(247,247,247,0)",
    alignSelf: "center",
    opacity: 1,
    borderRadius: 100,
    justifyContent: "center"
  },
  text3: {
    color: "rgba(255,255,255,1)",
    alignSelf: "center"
  },
  carrots: {
    width: 359,
    height: 109,
    marginLeft: 1
  },
  eggs: {
    width: 359,
    height: 109,
    marginLeft: 1
  },
  materialCardWithImageAndTitle2: {
    top: 0,
    left: 0,
    width: 359,
    height: 109,
    position: "absolute"
  },
  materialCardWithImageAndTitle3: {
    top: 108,
    left: 0,
    width: 359,
    height: 109,
    position: "absolute"
  },
  materialCardWithImageAndTitle2Stack: {
    width: 359,
    height: 217,
    marginLeft: 1
  },
  materialCardWithImageAndTitle4: {
    width: 359,
    height: 109,
    marginLeft: 1
  },
  materialCardWithImageAndTitle5: {
    width: 359,
    height: 109,
    marginLeft: 1
  }
});

export default Inventory;
